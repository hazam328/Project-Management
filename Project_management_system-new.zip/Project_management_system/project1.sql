drop table if exists project;
	create table project (
		id integer primary key autoincrement,
		name text not null,
		roll_no integer,
		team_member1 text not null,
		team_member2 text not null,
		final_project text not null,
		supervisor text not null,
		batch text not null,
		sessions integer
	);
	
